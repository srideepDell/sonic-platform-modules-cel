#!/bin/sh

__ScriptName=$0
runningMode=fore
logFileName=""
currentPath=`pwd`

OPT_RET=`getopt -o hdf: -n '*ERROR' -- "$@"`
if [ $? -ne 0 ];then
    echo "ERROR: exited with doing nothing." >&2
    exit 1
fi

usage()
{
    cat << EOT
    Usage: $__ScriptName [option] ...
    Running this executable script $__ScriptName, the module will be
    installed, a shell of switch SDK will be initialized as well.
    the shell is either BCM shell or remote shell developed by celestica.
    
    Options:
        -h, Display this message
        -d, The user portion of switch SDK will be running as daemon, 
            and a remote shell function will enable.
        -f fileName, The output content will save to file 'fileName',
            when the user portion becomes daemmon.Please use this option
            together with option '-d'.
    
    Example:
        1)As a foreground process
            $__ScriptName
        2)As a daemon, and display results with the stardand output
            $__ScriptName -d
        3)As a daemon, and save results to the file 'sdk.log'
            $__ScriptName -d -f sdk.log
    
EOT
}

eval set -- "$OPT_RET"
while true ;do
    case "$1" in
        -h)
            usage
            exit 1
            ;;
        -d)
            runningMode=daemon
            shift
            ;;
        -f)
            logFileName=$2
            shift 2
            ;;
        --)
            shift
            break
            ;;
        *)
            echo "ERROR: internal error!"
            exit 1
            ;;
    esac        
done

processName=`ps -aux | awk '{print $11 }' | grep "bcm.user"`
if [ -n "$processName" ]; then
    echo "Info:Running..."
    echo "Please stop the related process '${processName}', before starting.\n\r" >&2
    exit
fi

KernelBdeDriver=`lsmod | awk '{print $1 }' | grep "linux_kernel_bde"`
if [ "$KernelBdeDriver" = "linux_kernel_bde" ]; then
    echo "remove ko linux_bcm_knet linux_user_bde linux_kernel_bde"
    rmmod linux_bcm_knet
    rmmod linux_user_bde
    rmmod linux_kernel_bde
fi
insmod ./linux-kernel-bde.ko dmasize=32M himem=0
insmod ./linux-user-bde.ko
if [ -f /dev/linux-user-bde ] ; then
	echo "/dev/linux-user-bde file exists"       
else
	mknod /dev/linux-user-bde c 126 0
fi
if [ -f /dev/linux-kernel-bde ] ; then
	echo "/dev/linux-kernel-bde file exists"       
else
	mknod /dev/linux-kernel-bde c 127 0
fi
if [ -f config.bcm ] ; then
   export BCM_CONFIG_FILE=config.bcm
fi

sed -i -e 's|cls_cmd_daemon=1|cls_cmd_daemon=0|' config.bcm
rm -f /tmp/cls_sdk_fifo
rm -f /usr/local/bin/cel_bcmshell
if [ "${runningMode}" = "daemon" ];then
    findRet=`grep "cls_cmd_daemon" config.bcm`
    if [ -n "${findRet}" ];then
        sed -i -e 's|cls_cmd_daemon=0|cls_cmd_daemon=1|' config.bcm
    else
        echo "cls_cmd_daemon=1" >> config.bcm
    fi
    ln -s ${currentPath}/cls_shell /usr/local/bin/cel_bcmshell
fi

#./bcm.user

if [ "$runningMode" = "daemon" ]; then
    if [ -n "$logFileName" ];then
        ./bcm.user 1>${logFileName} 2>&1 &
    else
        ./bcm.user &
    fi
    while true;do   
        if [ -p /tmp/cls_sdk_fifo ]; then
            exit;
        fi
    done
else
    ./bcm.user
fi

